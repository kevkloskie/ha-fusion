<hr />

<style>
	hr {
		border-top: none;
		border-right: var(--theme-colors-sidebar-border);
		border-bottom: none;
		border-left: 1px solid rgba(0, 0, 0, 0.1);
		margin: 0 0.4rem;
	}

	/* Phone */
	@media all and (max-width: 768px) {
		hr {
			display: none;
		}
	}
</style>
