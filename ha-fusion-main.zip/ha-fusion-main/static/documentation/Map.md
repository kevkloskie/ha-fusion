# Map

For detailed maps, get a MapTiler API Key by following these steps:

1. Create free account
   <https://www.maptiler.com/>
2. Copy new key
   <https://cloud.maptiler.com/account/keys/>
3. In Fusion, paste key into
   Settings > Addons > Maptiler
4. Click Save
