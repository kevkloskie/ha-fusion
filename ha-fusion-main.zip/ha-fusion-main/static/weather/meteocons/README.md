<https://bas.dev/work/meteocons>
